package com.medialert.reminder

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var nameInput: EditText
    private lateinit var notes: TextView
    private lateinit var listBox: LinearLayout
    private lateinit var db: android.content.SharedPreferences
    private var hindi = true
    private val slots = arrayOf("सुबह / Morning", "दोपहर / Afternoon", "शाम / Evening", "रात / Night")
    private val slotHours = intArrayOf(8, 13, 18, 21)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = getSharedPreferences("medialert", MODE_PRIVATE)
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9)
        }
        render()
    }

    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFFF4FAFA.toInt())
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        val header = TextView(this).apply {
            text = "💊 Medi Alert"
            textSize = 28f
            setTextColor(0xFF075E66.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }
        root.addView(header)
        val lang = Button(this).apply {
            text = if (hindi) "English" else "हिंदी"
            setOnClickListener { hindi = !hindi; render() }
        }
        root.addView(lang)
        root.addView(label(if (hindi) "दवाई का नाम / Medicine name" else "Medicine name / दवाई का नाम"))
        nameInput = EditText(this).apply {
            hint = if (hindi) "जैसे: Vitamin D" else "e.g. Vitamin D"
            textSize = 17f
            setSingleLine(true)
        }
        root.addView(nameInput, matchWidth())
        root.addView(label(if (hindi) "रिमाइंडर का समय चुनें" else "Choose reminder times"))
        root.addView(TextView(this).apply {
            text = if (hindi) "हर चुने हुए समय पर रोज़ नोटिफिकेशन आएगा।" else "A daily notification will be scheduled for each selected time."
            textSize = 14f
            setTextColor(0xFF555555.toInt())
        })
        val checks = mutableListOf<CheckBox>()
        slots.forEachIndexed { index, slot ->
            val cb = CheckBox(this).apply {
                text = slot
                isChecked = true
                tag = index
            }
            checks.add(cb)
            root.addView(cb)
        }
        val customTime = Button(this).apply {
            text = if (hindi) "हर समय बदलें (वैकल्पिक)" else "Customize times (optional)"
        }
        root.addView(customTime)
        val times = intArrayOf(8, 13, 18, 21)
        customTime.setOnClickListener {
            val chosen = checks.indices.filter { checks[it].isChecked }
            if (chosen.isEmpty()) {
                Toast.makeText(this, if (hindi) "कम से कम एक समय चुनें" else "Select at least one time", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            chooseTime(chosen, 0, times)
        }

        val add = Button(this).apply {
            text = if (hindi) "दवाई सेव करें और रिमाइंडर लगाएँ" else "Save medicine & set reminders"
            setOnClickListener {
                val name = nameInput.text.toString().trim()
                if (name.isEmpty()) {
                    nameInput.error = if (hindi) "दवाई का नाम लिखें" else "Enter medicine name"
                    return@setOnClickListener
                }
                val chosen = checks.indices.filter { checks[it].isChecked }
                if (chosen.isEmpty()) {
                    Toast.makeText(this@MainActivity, if (hindi) "कम से कम एक समय चुनें" else "Select at least one time", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val items = readMedicines()
                val item = JSONObject().put("id", System.currentTimeMillis().toString())
                    .put("name", name).put("slots", JSONArray(chosen))
                    .put("hours", JSONArray(times.toList()))
                items.put(item)
                saveMedicines(items)
                scheduleItem(item, times)
                Toast.makeText(this@MainActivity, if (hindi) "दवाई सेव हो गई" else "Medicine saved", Toast.LENGTH_LONG).show()
                render()
            }
        }
        root.addView(add)
        root.addView(label(if (hindi) "आपकी दवाइयाँ / रिकॉर्ड" else "Your medicines / history"))
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox)
        showMedicines()
        val history = Button(this).apply {
            text = if (hindi) "आज का रिकॉर्ड देखें" else "View today's record"
            setOnClickListener { showHistory() }
        }
        root.addView(history)
        notes = TextView(this).apply { textSize = 14f; setPadding(0, 12, 0, 12) }
        root.addView(notes)
        root.addView(TextView(this).apply {
            text = if (hindi) "नोट: यह ऐप केवल याद दिलाता है; दवा की मात्रा/समय डॉक्टर या फार्मासिस्ट के निर्देशानुसार रखें।" else "Note: This app is a reminder only. Follow your clinician/pharmacist's instructions for medicine dose and timing."
            textSize = 12f
            setTextColor(0xFF666666.toInt())
            setPadding(0, 20, 0, 8)
        })
    }

    private fun chooseTime(chosen: List<Int>, position: Int, times: IntArray) {
        if (position >= chosen.size) return
        val slot = chosen[position]
        TimePickerDialog(this, { _, hour, minute ->
            times[slot] = hour
            // Minute values are handled in the regular reminder scheduler below as default :00.
            chooseTime(chosen, position + 1, times)
        }, times[slot], 0, false).apply {
            setTitle(slots[slot])
            show()
        }
    }

    private fun label(s: String) = TextView(this).apply {
        text = s; textSize = 17f; setTextColor(0xFF173D40.toInt())
        setPadding(0, 16, 0, 5)
    }
    private fun matchWidth() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

    private fun readMedicines(): JSONArray = try { JSONArray(db.getString("medicines", "[]")) } catch (_: Exception) { JSONArray() }
    private fun saveMedicines(a: JSONArray) { db.edit().putString("medicines", a.toString()).apply() }

    private fun showMedicines() {
        listBox.removeAllViews()
        val a = readMedicines()
        if (a.length() == 0) {
            listBox.addView(label(if (hindi) "अभी कोई दवाई सेव नहीं है।" else "No medicines saved yet."))
        }
        for (i in 0 until a.length()) {
            val obj = a.getJSONObject(i)
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 12, 12, 12); setBackgroundColor(0xFFFFFFFF.toInt()) }
            row.addView(TextView(this).apply {
                text = "💊 ${obj.optString("name")}"
                textSize = 18f
                setTextColor(0xFF075E66.toInt())
            })
            val selected = obj.optJSONArray("slots") ?: JSONArray()
            val names = (0 until selected.length()).map { slots.getOrElse(selected.optInt(it)) { "Time" } }
            row.addView(TextView(this).apply { text = names.joinToString(" • "); textSize = 13f })
            val taken = Button(this).apply {
                text = if (hindi) "आज ले ली ✓" else "Taken today ✓"
                setOnClickListener {
                    val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                    val key = "history_${date}"
                    val h = try { JSONArray(db.getString(key, "[]")) } catch (_: Exception) { JSONArray() }
                    h.put(JSONObject().put("name", obj.optString("name")).put("time", Date().time).put("status", "taken"))
                    db.edit().putString(key, h.toString()).apply()
                    Toast.makeText(this@MainActivity, if (hindi) "रिकॉर्ड सेव हो गया" else "Record saved", Toast.LENGTH_SHORT).show()
                }
            }
            row.addView(taken)
            val delete = Button(this).apply {
                text = if (hindi) "दवाई हटाएँ" else "Delete medicine"
                setOnClickListener {
                    val updated = JSONArray()
                    for (j in 0 until a.length()) if (j != i) updated.put(a.getJSONObject(j))
                    saveMedicines(updated)
                    cancelItem(obj)
                    render()
                }
            }
            row.addView(delete)
            listBox.addView(row)
        }
    }

    private fun showHistory() {
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val h = try { JSONArray(db.getString("history_${date}", "[]")) } catch (_: Exception) { JSONArray() }
        val lines = (0 until h.length()).map {
            val x = h.getJSONObject(it)
            val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(x.optLong("time")))
            "✓ ${x.optString("name")} — $time"
        }
        notes.text = if (lines.isEmpty()) {
            if (hindi) "आज का कोई रिकॉर्ड नहीं है।" else "No records for today."
        } else lines.joinToString("\n")
    }

    private fun scheduleItem(item: JSONObject, times: IntArray) {
        val id = item.optString("id").hashCode()
        val selected = item.optJSONArray("slots") ?: JSONArray()
        for (i in 0 until selected.length()) {
            val slot = selected.optInt(i)
            val hour = times.getOrElse(slot) { slotHours[slot] }
            val intent = Intent(this, ReminderReceiver::class.java).putExtra("name", item.optString("name"))
            val pi = PendingIntent.getBroadcast(this, id + slot, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            try {
                if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                else am.setExact(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            } catch (_: SecurityException) {
                am.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            }
        }
    }

    private fun cancelItem(item: JSONObject) {
        val id = item.optString("id").hashCode()
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        val selected = item.optJSONArray("slots") ?: JSONArray()
        for (i in 0 until selected.length()) {
            val slot = selected.optInt(i)
            val pi = PendingIntent.getBroadcast(this, id + slot, Intent(this, ReminderReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
            if (pi != null) am.cancel(pi)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("medicine_reminders", "Medicine reminders", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Daily reminders to take medicines"
                enableVibration(true)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val name = intent.getStringExtra("name") ?: "Medicine"
        val notification = Notification.Builder(context, if (Build.VERSION.SDK_INT >= 26) "medicine_reminders" else "")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Medi Alert 💊")
            .setContentText("Time to take: $name")
            .setAutoCancel(true)
            .setPriority(Notification.PRIORITY_HIGH)
            .build()
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Reminder rescheduling after reboot can be added; open the app once after installation
        // to grant notification and exact-alarm permissions.
    }
}
