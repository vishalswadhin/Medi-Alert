Medi Alert Android project (starter version)

यह Android Studio project है, तैयार APK नहीं।

इसमें शामिल:
- दवाई का नाम सेव करना
- चुने हुए सुबह/दोपहर/शाम/रात समय पर दैनिक reminder सेट करने की कोशिश
- हिंदी/English UI toggle
- Taken record और आज की history
- SharedPreferences में स्थानीय रिकॉर्ड

महत्वपूर्ण सीमाएँ:
1. Reminder notifications हैं, तेज़ ringing alarm नहीं।
2. Android की exact-alarm permission और notification permission डिवाइस/Android संस्करण के अनुसार माँगी जा सकती हैं।
3. Reboot के बाद reminder restore अभी लागू नहीं है।
4. Time customization में घंटे चुने जाते हैं; मिनट अभी 00 रहते हैं।
5. दवाई की सही खुराक और समय डॉक्टर/फार्मासिस्ट के निर्देश से तय करें।

APK बनाने के लिए Android Studio वाले कंप्यूटर या Android पर किसी compatible Android build environment की जरूरत होगी।
Project खोलें, Gradle sync करें, फिर Build > Build APK(s) चुनें।
